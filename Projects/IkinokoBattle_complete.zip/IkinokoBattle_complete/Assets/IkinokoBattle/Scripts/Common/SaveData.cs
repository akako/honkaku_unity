public class SaveData : SavableSingletonBase<SaveData>
{
    public int HighScore;
}
/// <summary>
/// セーブデータクラス
/// </summary>
public class SaveData : SavableSingletonBase<SaveData>
{
    /// <summary>
    /// ハイスコア
    /// </summary>
    public int HighScore;
}
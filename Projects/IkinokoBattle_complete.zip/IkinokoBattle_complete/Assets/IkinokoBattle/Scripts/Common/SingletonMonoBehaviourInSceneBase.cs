using System;
using UnityEngine;

public abstract class SingletonMonoBehaviourInSceneBase<T> : MonoBehaviour where T : MonoBehaviour
{
    /// <summary>
    /// シーンに1つしか存在しないオブジェクトのシングルトンです
    /// </summary>
    private static T _instance;

    public static T Instance => _instance;

    protected virtual void Awake()
    {
        if (null != _instance && _instance != this)
        {
            throw new Exception("シーン内に他のインスタンスが存在しています！");
        }

        _instance = this as T;
    }
}
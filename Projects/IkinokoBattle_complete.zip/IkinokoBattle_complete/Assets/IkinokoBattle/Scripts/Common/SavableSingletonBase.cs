﻿using UnityEngine;
using System;
using System.IO;
using System.Security.Cryptography;

/// <summary>
/// ファイルにデータを保存できるシングルトンです（該当ファイルはiCloudバックアップ対象から除外します）
/// </summary>
public abstract class SavableSingletonBase<T> where T : SavableSingletonBase<T>, new()
{
    private static T _instance;
    private bool _isLoaded;
    protected virtual bool IsSaveToPlayerPref => true;

    public static T Instance
    {
        get
        {
            if (null != _instance) return _instance;
            
            string json;
            _instance = new T();
            if (_instance.IsSaveToPlayerPref)
            {
                json = PlayerPrefs.GetString(SaveKey);
            }
            else
            {
                json = File.Exists(SavePath) ? File.ReadAllText(SavePath) : "";
            }
                
            if (string.IsNullOrEmpty(json) || !LoadFromJSON(json))
            {
                _instance._isLoaded = true;
            }
            return _instance;
        }
    }

    protected virtual string SerializedData => JsonUtility.ToJson(this);

    private static string SavePath => $"{Application.persistentDataPath}/{SaveKey}";

    private static string SaveKey
    {
        get
        {
            var provider = new SHA1CryptoServiceProvider();
            var hash = provider.ComputeHash(System.Text.Encoding.ASCII.GetBytes(typeof(T).FullName ?? throw new InvalidOperationException()));
            return BitConverter.ToString(hash);
        }
    }
    
    public static bool LoadFromJSON(string json)
    {
        try
        {
            _instance = JsonUtility.FromJson<T>(json);
            _instance._isLoaded = true;
            return true;
        }
        catch (Exception e)
        {
            Debug.LogWarning(e.ToString());
            return false;
        }
    }

    public void Save()
    {
        if (!_isLoaded) return;
        
        if (IsSaveToPlayerPref)
        {
            PlayerPrefs.SetString(SaveKey, SerializedData);
            PlayerPrefs.Save();
        }
        else
        {
            var path = SavePath;
            File.WriteAllText(path, SerializedData);
#if UNITY_IOS
            // iOSでデータをiCloudにバックアップさせない設定
            UnityEngine.iOS.Device.SetNoBackupFlag(path);
#endif
        }
    }

    public void Reset()
    {
        _instance = null;
    }

    public void Delete()
    {
        if (IsSaveToPlayerPref)
        {
            PlayerPrefs.DeleteKey(SaveKey);
            PlayerPrefs.Save();
        }
        else
        {
            if (File.Exists(SavePath))
            {
                File.Delete(SavePath);
            }                
        }

        _instance = null;
    }
}
﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityStandardAssets.CrossPlatformInput;

public class PlayerCharacterController : MonoBehaviour
{
    private void Start()
    {
        Debug.Log(Input.touchSupported ? "タッチに対応しています" : "タッチに対応していません");
    }

    private void Update()
    {
        if (Input.GetKey(KeyCode.LeftShift) && Input.GetKeyDown(KeyCode.Space))
        {
            Debug.Log("Shift+Spaceを押しました！");
        }

        Debug.Log("マウス座標: " + Input.mousePosition);
        Debug.Log("マウススクロール量: " + Input.mouseScrollDelta);

        Debug.Log(string.Format("現在のタッチ数は {0} です", Input.touchCount));

        foreach (var touch in Input.touches)
        {
            switch (touch.phase)
            {
                case TouchPhase.Began:
                    Debug.Log(string.Format("指ID: {0} タッチ開始 座標: {1}", touch.fingerId, touch.position));
                    break;
                case TouchPhase.Canceled:
                    Debug.Log(string.Format("指ID: {0} タッチキャンセル 座標: {1}", touch.fingerId, touch.position));
                    break;
                case TouchPhase.Ended:
                    Debug.Log(string.Format("指ID: {0} タッチ終了 座標: {1}", touch.fingerId, touch.position));
                    break;
                case TouchPhase.Moved:
                    Debug.Log(string.Format("指ID: {0} タッチ移動 座標: {1} 1フレームでの移動距離: {2}", touch.fingerId, touch.position,
                        touch.deltaPosition));
                    break;
                case TouchPhase.Stationary:
                    Debug.Log(string.Format("指ID: {0} タッチホールド(移動なし) 座標: {1}", touch.fingerId, touch.position));
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
        
        Debug.Log(string.Format("Axisを取得 ({0}, {1})",
            Input.GetAxis("Horizontal"), // 横軸の入力を取得
            Input.GetAxis("Vertical") // 縦軸の入力を取得
            ));
        
        if (Input.GetButtonDown("Jump"))
        {
            Debug.Log("Jumpボタンが押されたよ！");
        }
        
        
        if (CrossPlatformInputManager.GetButtonDown("Jump"))
        {
            Debug.Log("Jumpボタンが押されたよ！(CrossPlatformInputManager)");
        }
    }
}
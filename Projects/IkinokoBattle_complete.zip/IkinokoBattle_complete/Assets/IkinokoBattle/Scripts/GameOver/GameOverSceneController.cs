using UnityEngine;
using UnityEngine.UI;

public class GameOverSceneController : MonoBehaviour
{
    public static int Score;

    [SerializeField] private Text previousHighScoreText;
    [SerializeField] private Text scoreText;
    [SerializeField] private GameObject isHighScoreUpdatedMessage;

    private void Start()
    {
        var previousHighScore = SaveData.Instance.HighScore;
        previousHighScoreText.text = "" + previousHighScore;
        scoreText.text = "" + Score;

        if (previousHighScore < Score)
        {
            // スコアが前のハイスコアよりも高ければ、ハイスコアとして記録
            isHighScoreUpdatedMessage.SetActive(true);
            SaveData.Instance.HighScore = Score;
            SaveData.Instance.Save();
        }
        else
        {
            isHighScoreUpdatedMessage.SetActive(false);
        }
    }
}
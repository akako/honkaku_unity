using UnityEngine;
using UnityEngine.UI;

public class TitleSceneController : MonoBehaviour
{
    [SerializeField] private Text highScoreText;

    private void Start()
    {
        highScoreText.text = "" + SaveData.Instance.HighScore;
    }
}
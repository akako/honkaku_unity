﻿using UnityEngine;

/// <summary>
/// Mob（動くオブジェクト、MovingObjectの略）の状態管理スクリプト
/// </summary>
public abstract class MobStatus : MonoBehaviour
{
    /// <summary>
    /// 状態の定義
    /// </summary>
    protected enum StateEnum
    {
        Normal, // 通常
        Attack, // 攻撃中
        Die // 死亡
    }

    /// <summary>
    /// 移動可能かどうか
    /// </summary>
    public bool IsMovable => StateEnum.Normal == State;

    /// <summary>
    /// 攻撃可能かどうか
    /// </summary>
    public bool IsAttackable => StateEnum.Normal == State;

    /// <summary>
    /// ライフ最大値を返します
    /// </summary>
    public float LifeMax => lifeMax;

    /// <summary>
    /// ライフの値を返します
    /// </summary>
    public float Life => _life;

    [SerializeField] private float lifeMax = 10; // ライフ最大値
    protected Animator Animator;
    protected StateEnum State = StateEnum.Normal; // Mob状態
    private float _life; // 現在のライフ値（ヒットポイント）
    // Animatorの値キーを文字列で指定するのは非効率なため、先にIDに変換しておく
    private static readonly int Attack = Animator.StringToHash("Attack");
    private static readonly int Die = Animator.StringToHash("Die");

    protected virtual void Start()
    {
        _life = lifeMax; // 初期状態はライフ満タン
        Animator = GetComponentInChildren<Animator>();

        // ライフゲージの表示開始
        LifeGaugeContainer.Instance.Add(this);
    }

    protected virtual void OnDamaged()
    {
    }

    /// <summary>
    /// キャラが倒れた時の処理を記述します。
    /// </summary>
    protected virtual void OnDie()
    {
        // Colliderを非アクティブに
        GetComponent<Collider>().enabled = false;
    }

    private void OnDestroy()
    {
        // ライフゲージの表示終了
        LifeGaugeContainer.Instance.Remove(this);
    }

    /// <summary>
    /// 指定値のダメージを受けます。
    /// </summary>
    /// <param name="damage"></param>
    public void Damage(float damage)
    {
        if (State == StateEnum.Die) return;

        _life -= damage;

        if (_life > 0)
        {
            OnDamaged();
            return;
        }

        State = StateEnum.Die;
        Animator.SetTrigger(Die);

        OnDie();
    }

    /// <summary>
    /// 可能であれば攻撃中の状態に遷移します。
    /// </summary>
    public void GoToAttackStateIfPossible()
    {
        if (!IsAttackable) return;

        State = StateEnum.Attack;
        Animator.SetTrigger(Attack);
    }

    /// <summary>
    /// 可能であればNormalの状態に遷移します。
    /// </summary>
    public void GoToNormalStateIfPossible()
    {
        if (State == StateEnum.Die) return;

        State = StateEnum.Normal;
    }
}
﻿using System.Collections;
using UnityEngine;

/// <summary>
/// 攻撃制御クラス
/// </summary>
[RequireComponent(typeof(MobStatus))]
public class PlayerAttack : MobAttack
{
    [SerializeField] private TrailRenderer trailParticle;

    protected override void Start()
    {
        trailParticle.enabled = false;
        base.Start();
    }

    public override void OnAttackStart()
    {
        trailParticle.enabled = true;
        base.OnAttackStart();
        if (Random.Range(0f, 100f) < 10f)
        {
            PopupMessageContainer.Instance.PopupMessage(transform, "えいっ", 0.7f);
        }
    }

    public override void OnAttackFinished()
    {
        trailParticle.enabled = false;
        base.OnAttackFinished();
    }
}
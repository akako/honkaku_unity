using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 満腹度バーコンテナ
/// </summary>
public class SatietyContainer : MonoBehaviour
{
    [SerializeField] private PlayerStatus playerStatus;
    [SerializeField] private Image fill;

    private void Update()
    {
        // 満腹度に応じてバーを更新
        fill.fillAmount = playerStatus.Satiety;
    }
}
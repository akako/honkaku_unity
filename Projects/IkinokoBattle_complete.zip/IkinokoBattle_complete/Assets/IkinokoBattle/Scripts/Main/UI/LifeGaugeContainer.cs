﻿using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(RectTransform))]
public class LifeGaugeContainer : SingletonMonoBehaviourInSceneBase<LifeGaugeContainer>
{
    [SerializeField] private Camera mainCamera; // ライフゲージ表示対象のMobを映しているカメラ
    [SerializeField] private LifeGauge lifeGaugePrefab; // ライフゲージのPrefab

    private RectTransform _rectTransform;

    private readonly Dictionary<MobStatus, LifeGauge>
        _statusLifeBarMap = new Dictionary<MobStatus, LifeGauge>(); // アクティブなライフゲージを保持するコンテナ

    protected override void Awake()
    {
        base.Awake();
        _rectTransform = GetComponent<RectTransform>();
    }

    /// <summary>
    /// ライフゲージを追加します。
    /// </summary>
    /// <param name="status"></param>
    public void Add(MobStatus status)
    {
        var lifeGauge = Instantiate(lifeGaugePrefab, transform);
        lifeGauge.Initialize(_rectTransform, mainCamera, status);
        _statusLifeBarMap.Add(status, lifeGauge);
    }

    /// <summary>
    /// ライフゲージを破棄します。
    /// </summary>
    /// <param name="status"></param>
    public void Remove(MobStatus status)
    {
        if (_statusLifeBarMap.ContainsKey(status) && _statusLifeBarMap[status] != null &&
            _statusLifeBarMap[status].gameObject != null)
        {
            Destroy(_statusLifeBarMap[status].gameObject);
        }

        _statusLifeBarMap.Remove(status);
    }
}
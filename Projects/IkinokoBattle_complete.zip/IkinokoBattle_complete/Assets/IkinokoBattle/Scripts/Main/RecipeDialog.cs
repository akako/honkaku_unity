﻿using UnityEngine;

public class RecipeDialog : MonoBehaviour {
	private void Start()
	{
		// 初期状態は非表示
		gameObject.SetActive(false);
	}

	/// <summary>
	/// レシピ欄の表示/非表示を切り替えます。
	/// </summary>
	public void Toggle()
	{
		gameObject.SetActive(!gameObject.activeSelf);
	}
}

﻿using System;
using DG.Tweening;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Events;
using Random = UnityEngine.Random;

/// <summary>
/// 敵の状態管理スクリプト
/// </summary>
[RequireComponent(typeof(NavMeshAgent))]
public class EnemyStatus : MobStatus
{
    [SerializeField] private CollisionDetector attackHitDetector;
    [SerializeField] private UnityEvent onDamaged = new UnityEvent();
    
    protected NavMeshAgent _agent;

    protected override void Start()
    {
        base.Start();
        
        _agent = GetComponent<NavMeshAgent>();
    }

    private void Update()
    {
        // NavMeshAgentのvelocityで移動速度のベクトルが取得できる
        _animator.SetFloat("MoveSpeed", _agent.velocity.magnitude);
    }

    protected override void OnDie()
    {
        base.OnDie();
        // 攻撃の当たり判定を消す
        if (attackHitDetector != null)
        {
            attackHitDetector.gameObject.SetActive(false);
        }

        // 倒された時の消滅アニメーション
        transform.DOScaleY(0f, 3f)
            .OnComplete(() => { Destroy(gameObject); });

        if (Random.Range(0f, 100f) < 30f)
        {
            PopupMessageContainer.Instance.PopupMessage(transform, "ヤラレター！", 0.7f);
        }
    }

    protected override void OnDamaged()
    {
        base.OnDamaged();
        onDamaged.Invoke();
    }
}
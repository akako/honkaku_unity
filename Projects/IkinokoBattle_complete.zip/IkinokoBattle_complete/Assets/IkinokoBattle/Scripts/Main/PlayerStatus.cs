﻿using UnityEngine;

public class PlayerStatus : MobStatus
{
    private const float SatietyMax = 100f;

    private float _satietyValue;

    /// <summary>
    /// 満腹度
    /// </summary>
    public float Satiety => _satietyValue / SatietyMax;

    public float SatietyValue
    {
        get => _satietyValue;
        set
        {
            var prevSatiety = Satiety;
            _satietyValue = Mathf.Clamp(value, 0f, SatietyMax);
            if (prevSatiety > 0.3f && Satiety <= 0.3f)
            {
                PopupMessageContainer.Instance.PopupMessage(transform, "おなかすいた・・・");
            }
            else if (prevSatiety > 0.1f && Satiety <= 0.1f)
            {
                PopupMessageContainer.Instance.PopupMessage(transform, "腹ペコで\nたおれそう・・・");
            }
        }
    }

    protected override void Start()
    {
        base.Start();

        _satietyValue = SatietyMax;

        OwnedItemsData.Instance.Add(Item.ItemType.Wood);
        OwnedItemsData.Instance.Save();

        foreach (var item in OwnedItemsData.Instance.OwnedItems)
        {
            Debug.Log(item.Type + "を" + item.Number + "個所持");
        }
    }

    private void Update()
    {
        if (Satiety <= 0)
        {
            // 満腹度が0になったら倒れる
            Damage(LifeMax);
        }
    }

    protected override void OnDie()
    {
        base.OnDie();
        MainSceneController.Instance.GameOver();
    }
}
﻿using System.Collections;
using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
[RequireComponent(typeof(EnemyStatus))]
public class EnemyMove : MonoBehaviour
{
    [SerializeField] private LayerMask raycastLayerMask; // レイヤーマスク
    [SerializeField] private Transform moveTargetDetector;
    private NavMeshAgent _agent;
    private readonly RaycastHit[] _raycastHits = new RaycastHit[10];
    private EnemyStatus _status;
    private float _baseSpeed;

    private void Start()
    {
        _agent = GetComponent<NavMeshAgent>(); // NavMeshAgentを保持しておく
        _baseSpeed = _agent.speed;
        _status = GetComponent<EnemyStatus>();

        StartCoroutine(RandomMove());
    }

    /// <summary>
    /// プレイヤーを検知していない間、ランダムでうろうろする処理
    /// </summary>
    /// <returns></returns>
    private IEnumerator RandomMove()
    {
        while (true)
        {
            if (_agent.pathStatus != NavMeshPathStatus.PathInvalid && _status.IsMovable && !_agent.hasPath)
            {
                // 適当に、近くの座標に移動する
                _agent.destination = transform.position +
                                     new Vector3(Random.Range(-2f, 2f), Random.Range(-2f, 2f)).normalized *
                                     Random.Range(0.5f, 4f);
            }

            // 2.5秒〜5秒待つ
            yield return new WaitForSeconds(Random.Range(2.5f, 5f));
        }
    }

    public void OnDetectObject(Collider other)
    {
        if (!_agent) return;

        if (null != _status && !_status.IsMovable)
        {
            _agent.isStopped = true;
            return;
        }

        // 夜は索敵範囲を2倍に広げ、移動速度も2倍にする
        moveTargetDetector.localScale = MainSceneController.Instance.IsNight ? Vector3.one * 2 : Vector3.one;
        _agent.speed = MainSceneController.Instance.IsNight ? _baseSpeed * 2 : _baseSpeed;

        var selfPosition = transform.position + new Vector3(0, 0.5f); // 地面ギリギリだと凹凸が邪魔をするので、キャラの位置のちょっと上を基準点とする

        var positionDiff = other.transform.position + new Vector3(0, 0.5f) - selfPosition; // 自身とプレイヤーの座標差分を計算
        var distance = positionDiff.magnitude; // プレイヤーとの距離を計算
        var direction = positionDiff.normalized; // プレイヤーへの方向

        // _raycastHitsに、ヒットしたColliderや座標情報などが格納される
        // RaycastAllとRaycastNonAllocは同等の機能だが、RaycastNonAllocだとメモリにゴミが残らないのでこちらを推奨
        var hitCount = Physics.RaycastNonAlloc(selfPosition, direction, _raycastHits, distance, raycastLayerMask);
        if (hitCount == 0)
        {
            // 本作のプレイヤーはCharacterControllerを使っていて、Colliderは使っていないのでRaycastはヒットしない
            // つまり、ヒット数が0であればプレイヤーとの間に障害物が無いということになる
            _agent.isStopped = false;
            _agent.destination = other.transform.position;
        }
        else
        {
            // 見失ったら停止する
            _agent.isStopped = true;
        }
    }
}
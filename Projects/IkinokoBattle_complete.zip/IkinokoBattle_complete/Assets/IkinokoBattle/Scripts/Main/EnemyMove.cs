﻿using System.Collections;
using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
[RequireComponent(typeof(EnemyStatus))]
public class EnemyMove : MonoBehaviour
{
    [SerializeField] private LayerMask raycastLayerMask; // レイヤーマスク
    [SerializeField] private Transform moveTargetDetector;
    private NavMeshAgent _agent;
    private RaycastHit[] _raycastHits = new RaycastHit[10];
    private EnemyStatus _status;
    private float _baseSpeed;

    private void Start()
    {
        _agent = GetComponent<NavMeshAgent>(); // NavMeshAgentを保持しておく
        _baseSpeed = _agent.speed;
        _status = GetComponent<EnemyStatus>();
        
        StartCoroutine(RandomMove());
    }
    
    private IEnumerator RandomMove()
    {
        while (true)
        {
            if (_agent.pathStatus != NavMeshPathStatus.PathInvalid && _status.IsMovable && !_agent.hasPath)
            {
                _agent.destination = transform.position + new Vector3(Random.Range(-2f, 2f), Random.Range(-2f, 2f)).normalized * Random.Range(0.5f, 4f);
            }
            yield return new WaitForSeconds(Random.Range(2.5f, 5f));
        }
    }

    public void OnDetectObject(Collider collider)
    {
        if (!_agent) return;
        
        if (null != _status && !_status.IsMovable)
        {
            _agent.isStopped = true;
            return;
        }

        // 夜は索敵範囲を広げ、2倍のスピードで動かす
        moveTargetDetector.localScale = MainSceneController.Instance.IsNight ? Vector3.one * 2 : Vector3.one;
        _agent.speed = MainSceneController.Instance.IsNight ? _baseSpeed * 2 : _baseSpeed;

        var selfPosition = transform.position + new Vector3(0, 0.5f); // 地面ギリギリだと凹凸が邪魔をするので、キャラの位置のちょっと上を基準点とする
        
        var positionDiff = collider.transform.position + new Vector3(0, 0.5f) - selfPosition; // 自身とプレイヤーの座標差分を計算
        var distance = positionDiff.magnitude; // プレイヤーとの距離を計算
        var direction = positionDiff.normalized; // プレイヤーへの方向
        
        // _raycastHitsに、ヒットしたColliderや座標情報などが格納される
        // RaycastAllとRaycastNonAllocは同等の機能だが、RaycastNonAllocだとメモリにゴミが残らないのでこちらを推奨
        var hitCount = Physics.RaycastNonAlloc(selfPosition, direction, _raycastHits, distance, raycastLayerMask);
        if (hitCount == 0)
        {
            // 本作のプレイヤーはCharacterControllerを使っていて、Colliderは使っていないのでRaycastはヒットしない
            // つまり、ヒット数が0であればプレイヤーとの間に障害物が無いということになる
            _agent.isStopped = false;
            _agent.destination = collider.transform.position;
        }
        else
        {
            // 見失ったら停止する
            _agent.isStopped = true;
        }
    }
}
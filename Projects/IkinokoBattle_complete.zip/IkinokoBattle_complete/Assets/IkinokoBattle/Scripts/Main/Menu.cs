﻿using UnityEngine;
using UnityEngine.UI;

public class Menu : SingletonMonoBehaviourInSceneBase<Menu>
{
    [SerializeField] private Button pauseButton;
    [SerializeField] private GameObject pausePanel;
    [SerializeField] private Button resumeButton;

    [SerializeField] private Text scoreText;
    [SerializeField] private Button itemsButton;
    [SerializeField] private Button recipeButton;
    [SerializeField] private Button throwAxeButton;
    [SerializeField] private Text throwAxeNumberText;
    [SerializeField] private GameObject throwAxeCursor;

    [SerializeField] private ItemsDialog itemsDialog;
    [SerializeField] private RecipeDialog recipeDialog;
    
    private void Start()
    {
        pausePanel.SetActive(false); // ポーズのパネルは初期状態では非表示にしておく

        pauseButton.onClick.AddListener(Pause);
        resumeButton.onClick.AddListener(Resume);
        itemsButton.onClick.AddListener(ToggleItemsDialog);
        recipeButton.onClick.AddListener(ToggleRecipeDialog);
        throwAxeButton.onClick.AddListener(() =>
        {
            PlayerController.Instance.ToggleReadyToThrow();
        });
    }

    private void Update()
    {
        scoreText.text = "" + MainSceneController.Instance.MinutesInGame;
        var throwAxeItem = OwnedItemsData.Instance.GetItem(Item.ItemType.ThrowAxe);
        var throwAxeNumber = throwAxeItem?.Number ?? 0;
        throwAxeNumberText.text = "" + throwAxeNumber;
        throwAxeButton.interactable = throwAxeNumber > 0;
    }

    public bool IsThrowAxeActive
    {
        set
        {
            throwAxeButton.image.color = value ? Color.red : Color.white;
            throwAxeCursor.SetActive(value);
        }
    }

    /// <summary>
    /// ゲームを一時停止します。
    /// </summary>
    private void Pause()
    {
        Time.timeScale = 0; // Time.timeScaleで時間の流れの速さを決める。0だと時間が停止する
        pausePanel.SetActive(true);
    }

    /// <summary>
    /// ゲームを再開します。
    /// </summary>
    private void Resume()
    {
        Time.timeScale = 1; // また時間が流れるようにする
        pausePanel.SetActive(false);
    }

    /// <summary>
    /// アイテムウインドウを開閉します。
    /// </summary>
    private void ToggleItemsDialog()
    {
        itemsDialog.Toggle();
    }

    /// <summary>
    /// レシピウインドウを開閉します。
    /// </summary>
    private void ToggleRecipeDialog()
    {
        recipeDialog.Toggle();
    }
}
﻿using System.Collections;
using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
[RequireComponent(typeof(EnemyStatus))]
public class EnemyMoveEscape : MonoBehaviour
{
    [SerializeField] private LayerMask raycastLayerMask; // レイヤーマスク
    private NavMeshAgent _agent;
    private RaycastHit[] _raycastHits = new RaycastHit[10];
    private EnemyStatus _status;

    private void Start()
    {
        _agent = GetComponent<NavMeshAgent>();
        _status = GetComponent<EnemyStatus>();

        StartCoroutine(RandomMove());
    }

    private IEnumerator RandomMove()
    {
        while (true)
        {
            if (_agent.pathStatus != NavMeshPathStatus.PathInvalid && _status.IsMovable && !_agent.hasPath)
            {
                _agent.destination = transform.position + new Vector3(Random.Range(-2f, 2f), Random.Range(-2f, 2f));
            }
            yield return new WaitForSeconds(Random.Range(0.5f, 2f));
        }
    }

    public void OnDetectObject(Collider collider)
    {
        if (!_agent) return;
        
        if (null != _status && !_status.IsMovable)
        {
            _agent.isStopped = true;
            return;
        }

        var selfPosition = transform.position + new Vector3(0, 0.5f);
        
        var positionDiff = collider.transform.position + new Vector3(0, 0.5f) - selfPosition;
        var distance = positionDiff.magnitude; // プレイヤーとの距離を計算
        var direction = positionDiff.normalized; // プレイヤーへの方向
        
        var hitCount = Physics.RaycastNonAlloc(selfPosition, direction, _raycastHits, distance, raycastLayerMask);
        if (hitCount != 0) return;
        
        _agent.isStopped = false;
        _agent.destination = collider.transform.position - direction * 10f;
    }

    public void Escape()
    {
        if (!_agent) return;
        
        _agent.destination = transform.position + new Vector3(Random.Range(-1f, 1f), Random.Range(-1f, 1f)).normalized * 15f;
    }
}
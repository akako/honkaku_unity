﻿using UnityEngine;

/// <summary>
/// ＠ミニマップ解説＠
/// このスクリプトは、ミニマップ用のカメラをプレイヤーの頭上で固定することしか行っていない。ミニマップ作成のポイントは以下のとおり。
/// ・ミニマップに表示するためのマーカーしか映さないよう、CameraコンポーネントのCulling Maskで、カメラで映すレイヤーを指定している。
/// ・CameraコンポーネントのTarget Texture（映像出力先）にミニマップ用テクスチャを指定し、ミニマップを出力している。
/// ・ミニマップのUIとしてRawImageを使っている。RawImageはテクスチャをそのまま表示できるので、前述のミニマップ用テクスチャを表示している。
/// ・ミニマップのUIにMaskコンポーネントをアタッチし、丸く切り抜いている。
/// </summary>
public class MiniMapCamera : MonoBehaviour
{
    [SerializeField] private Transform player;

    private void Update()
    {
        transform.position = player.position + Vector3.up * 50;
    }
}
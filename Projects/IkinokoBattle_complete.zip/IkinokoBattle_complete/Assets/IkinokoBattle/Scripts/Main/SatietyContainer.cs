using System;
using UnityEngine;
using UnityEngine.UI;

public class SatietyContainer : MonoBehaviour
{
    [SerializeField] private PlayerStatus playerStatus;
    [SerializeField] private Image fill;

    private void Update()
    {
        fill.fillAmount = playerStatus.Satiety;
    }
}
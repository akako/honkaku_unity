﻿using System.Collections;
using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(SpawnerManager))]
public class Spawner : MonoBehaviour
{
    [SerializeField] private PlayerStatus playerStatus;
    [SerializeField] private GameObject enemyPrefab;

    private SpawnerManager _manager;

    private void Start()
    {
        _manager = GetComponent<SpawnerManager>();

        StartCoroutine(SpawnLoop()); // Coroutineを開始
    }

    /// <summary>
    /// 敵出現のCoroutine
    /// </summary>
    /// <returns></returns>
    private IEnumerator SpawnLoop()
    {
        while (true)
        {
            var passedDay = MainSceneController.Instance.PassedDay;

            _manager.RefreshEnemies();
            if (_manager.IsSpawnable)
            {
                var distanceVector = new Vector3(5, 0);
                // プレイヤーの位置をベースにした敵の出現位置。Y軸に対して上記ベクトルをランダムに0°〜360°回転させている
                var spawnPositionFromPlayer = Quaternion.Euler(0, Random.Range(0, 360f), 0) * distanceVector *
                                              Random.Range(2.5f - Mathf.Min(0.5f * passedDay, 1.5f), 4f);
                // 敵を出現させたい位置を決定
                var spawnPosition = playerStatus.transform.position + spawnPositionFromPlayer;

                // 指定座標から一番近いNavMeshの座標を探す
                if (NavMesh.SamplePosition(spawnPosition, out var navMeshHit, 10, NavMesh.AllAreas))
                {
                    // enemyPrefabを複製、NavMeshAgentは必ずNavMesh上に配置する
                    var enemy = Instantiate(enemyPrefab, navMeshHit.position, Quaternion.identity);
                    _manager.AddEnemy(enemy);
                }
            }

            // 指定秒待つ
            yield return new WaitForSeconds(8f - Mathf.Min(2f * passedDay, 6f));

            if (playerStatus.Life <= 0)
            {
                // プレイヤーが倒れたらループを抜ける
                break;
            }
        }
    }
}
using UnityEngine;

public class PlayerPrefsTest : MonoBehaviour
{
    // PlayerPrefsのデータ読み書きに使うキーは、タイプミスを避けるために定数化しておいた方がGOOD
    private const string TestKey = "TEST"; 
    private void Start()
    {
        var testData = "This is Test!!";
        
        // Stringの保存
        PlayerPrefs.SetString(TestKey, testData);
        PlayerPrefs.Save();
        
        // 保存したStringの読み込み
        var savedData = PlayerPrefs.GetString(TestKey);
        Debug.Log(savedData);
    }
}
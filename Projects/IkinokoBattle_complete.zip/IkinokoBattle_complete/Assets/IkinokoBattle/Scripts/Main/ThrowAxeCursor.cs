﻿using UnityEngine;

public class ThrowAxeCursor : MonoBehaviour
{
    private void Update()
    {
        transform.position = Input.mousePosition;
    }
}

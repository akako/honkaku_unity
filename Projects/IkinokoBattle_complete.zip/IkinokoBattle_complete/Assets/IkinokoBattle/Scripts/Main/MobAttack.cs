﻿using System.Collections;
using UnityEngine;

/// <summary>
/// 攻撃制御クラス
/// </summary>
[RequireComponent(typeof(MobStatus))]
public class MobAttack : MonoBehaviour
{
    [SerializeField] private float attackCooldown = 0.5f; // 攻撃後のクールダウン（秒）
    [SerializeField] private Collider attackCollider;
    [SerializeField] private AudioSource swingSound;
    [SerializeField] private AudioSource hitSound;

    private MobStatus _status;

    protected virtual void Start()
    {
        _status = GetComponent<MobStatus>();
    }

    /// <summary>
    /// 攻撃可能な状態であれば攻撃を行います。
    /// </summary>
    public void AttackIfPossible()
    {
        if (!_status.IsAttackable) return; // ステータスと衝突したオブジェクトで攻撃可否を判断

        _status.GoToAttackStateIfPossible();
        MainSceneController.Instance.MinutesInGame += MainSceneController.IncrementMinutesPerAttack;
    }

    /// <summary>
    /// 攻撃対象が攻撃範囲に入った時に呼ばれます。
    /// </summary>
    /// <param name="collider"></param>
    public void OnAttackRangeEnter(Collider collider)
    {
        AttackIfPossible();
    }

    public virtual void OnAttackReady()
    {
        attackCollider.gameObject.SetActive(true);
        attackCollider.enabled = false;
    }

    /// <summary>
    /// 攻撃の開始時に呼ばれます。
    /// </summary>
    public virtual void OnAttackStart()
    {
        attackCollider.gameObject.SetActive(true);
        attackCollider.enabled = true;
        
        // 武器を振る音の再生。再生ピッチをランダムに変化させ、毎回少し違った音が出るようにする
        swingSound.pitch = Random.Range(0.7f, 1.3f);
        swingSound.Play();
    }
    
    /// <summary>
    /// attackColliderが攻撃対象にHitした時に呼ばれます。
    /// </summary>
    /// <param name="collider"></param>
    public void OnHitAttack(Collider collider)
    {
        var targetMob = collider.GetComponent<MobStatus>();
        if (null == targetMob) return;
        
        // プレイヤーにダメージを与える
        targetMob.Damage(1);
        hitSound.pitch = Random.Range(0.7f, 1.3f);
        hitSound.Play();
    }
    
    /// <summary>
    /// 攻撃の終了時に呼ばれます。
    /// </summary>
    public virtual void OnAttackFinished()
    {
        attackCollider.enabled = false;
        attackCollider.gameObject.SetActive(false);
        StartCoroutine(CooldownCoroutine());
    }

    private IEnumerator CooldownCoroutine()
    {
        yield return new WaitForSeconds(attackCooldown);
        _status.GoToNormalStateIfPossible();        
    }
}
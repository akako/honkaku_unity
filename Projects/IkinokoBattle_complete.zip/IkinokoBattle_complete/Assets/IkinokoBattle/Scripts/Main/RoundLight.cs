﻿using UnityEngine;

public class RoundLight : SingletonMonoBehaviourInSceneBase<RoundLight>
{
    public Light Light => _light;

    private Light _light;

    private void Start()
    {
        _light = GetComponent<Light>();
    }

    public void RotateTo(Vector3 to)
    {
        transform.eulerAngles = to;
    }
}
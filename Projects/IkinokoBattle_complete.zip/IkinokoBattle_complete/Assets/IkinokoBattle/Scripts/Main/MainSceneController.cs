using System.Collections;
using DG.Tweening;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainSceneController : SingletonMonoBehaviourInSceneBase<MainSceneController>
{
    public const int IncrementMinutesPerAttack = 10;
    public const int IncrementMinutesPerCreateItem = 5;

    /// <summary>
    /// いま、夜かどうか
    /// </summary>
    public bool IsNight { get; private set; }

    /// <summary>
    /// ゲーム内の経過日数
    /// </summary>
    public int PassedDay => _minutesInGame / MinutesOnDay;

    private const int MinutesOnDay = 24 * 60 * 5;

    [SerializeField] private PlayerStatus playerStatus;

    // ゲーム世界の経過時間（分）
    private int _minutesInGame;
    private bool _isGameOver;

    public int MinutesInGame
    {
        get => _minutesInGame;
        set
        {
            if (_isGameOver) return;

            var elapsedMinutes = value - _minutesInGame;
            playerStatus.SatietyValue -= elapsedMinutes / 100f;

            _minutesInGame = value;
            var xDegree = (90f + 360f / MinutesOnDay * (_minutesInGame % MinutesOnDay)) % 360f;
            RoundLight.Instance.RotateTo(new Vector3(xDegree, -60f));
            // 夜は光の強さを0に
            var prevIsNight = IsNight;
            IsNight = xDegree < 0 || 180 < xDegree;
            if (!prevIsNight && IsNight)
            {
                DOTween.To(v => RoundLight.Instance.Light.intensity = v, 1f, 0f, 5f);
            }
            else if (prevIsNight && !IsNight)
            {
                DOTween.To(v => RoundLight.Instance.Light.intensity = v, 0f, 1f, 5f);
            }
        }
    }


    public void EatItem()
    {
        playerStatus.SatietyValue += 10;
    }

    private void Start()
    {
        MinutesInGame = 0;
        // 時間経過処理
        StartCoroutine(TimerLoop());
    }

    public void GameOver()
    {
        _isGameOver = true;
        DOVirtual.DelayedCall(3, () =>
        {
            GameOverSceneController.Score = MinutesInGame;
            SceneManager.LoadScene("GameOverScene");
        });
    }

    private IEnumerator TimerLoop()
    {
        while (!_isGameOver)
        {
            yield return new WaitForSeconds(0.1f);
            MinutesInGame += 5;
        }
    }
}
﻿using UnityEngine;
using UnityEngine.EventSystems;
using UnityStandardAssets.CrossPlatformInput;
using Vector3 = UnityEngine.Vector3;

[RequireComponent(typeof(CharacterController))]
[RequireComponent(typeof(PlayerStatus))]
[RequireComponent(typeof(MobAttack))]
public class PlayerController : SingletonMonoBehaviourInSceneBase<PlayerController>
{
    [SerializeField] private Animator animator;
    [SerializeField] private float moveSpeed = 3; // 移動速度
    [SerializeField] private float jumpPower = 3; // ジャンプ力// 重力加速度
    [SerializeField] private ThrowAxe throwAxePrefab;
    private CharacterController _characterController; // CharacterControllerのキャッシュ
    private Transform _transform; // Transformのキャッシュ
    private Vector3 _moveVelocity; // キャラの移動速度情報
    private PlayerStatus _status;
    private MobAttack _attack;
    
    /// <summary>
    /// 接地判定処理
    /// </summary>
    private bool IsGrounded
    {
        get
        {
            var ray = new Ray(_transform.position + new Vector3(0, 0.1f), Vector3.down);
            var raycastHits = new RaycastHit[1];
            var hitCount = Physics.RaycastNonAlloc(ray, raycastHits, 0.2f);
            return hitCount >= 1;
        }
    }

    private bool IsReadyToThrow
    {
        get => _isReadyToThrow;
        set
        {
            _isReadyToThrow = value;
            Menu.Instance.IsThrowAxeActive = _isReadyToThrow;
        }
    }

    private bool _isReadyToThrow;

    public void ToggleReadyToThrow()
    {
        if (OwnedItemsData.Instance.GetItem(Item.ItemType.ThrowAxe).Number <= 0)
        {
            IsReadyToThrow = false;
        }
        else
        {
            IsReadyToThrow = !IsReadyToThrow;
            
        }
        Debug.Log("投擲モード" + (IsReadyToThrow ? "ON" : "OFF"));
    }
    
    private void Start()
    {
        _characterController = GetComponent<CharacterController>(); // 毎フレームアクセスするので、負荷を下げるためにキャッシュしておく
        _transform = transform; // Transformもキャッシュすると少しだけ負荷が下がる
        _status = GetComponent<PlayerStatus>();
        _attack = GetComponent<MobAttack>();
    }

    private void Update()
    {
        if (EventSystem.current.IsPointerOverGameObject())
        {
            // UI上にマウスポインタがある場合はアクションしない
            return;
        }
        
        if (CrossPlatformInputManager.GetButtonUp("Fire1"))
        {
            if (IsReadyToThrow)
            {
                // 投擲の準備中であれば、投擲
                if (OwnedItemsData.Instance.GetItem(Item.ItemType.ThrowAxe).Number <= 0)
                {
                    Debug.Log("投げオノを持ってないよ〜");
                }
                else
                {
                    var mousePointerRay = Camera.main.ScreenPointToRay(CrossPlatformInputManager.mousePosition);
                    if (Physics.Raycast(mousePointerRay, out var hit))
                    {
                        var throwAxe = Instantiate(throwAxePrefab);
                        var target = hit.collider.name == "Terrain" ? hit.point : hit.collider.transform.position + Vector3.up;
                        throwAxe.Initialize(transform.position + Vector3.up, target, 20f);
                        OwnedItemsData.Instance.Use(Item.ItemType.ThrowAxe);
                        OwnedItemsData.Instance.Save();
                        AudioManager.Instance.Play("throw");
                        if (OwnedItemsData.Instance.GetItem(Item.ItemType.ThrowAxe).Number <= 0)
                        {
                            IsReadyToThrow = false;
                        }
                    }
                }
            }
            else
            {
                // Fire1ボタン（デフォルトだとマウス左クリック）で攻撃
                _attack.AttackIfPossible();
            }
        }
        
        if (CrossPlatformInputManager.GetButtonUp("Fire2"))
        {
            // Fire2ボタン（デフォルトだとマウス左クリック）で投擲スタンバイ/解除
            ToggleReadyToThrow();
        }
        
        Debug.Log(IsGrounded ? "地上にいます" : "空中です");

        if (_status.IsMovable) // 移動可能な状態であれば、ユーザ入力を移動に反映する
        {
            // 入力軸による移動処理（慣性を無視しているので、キビキビ動く）
            _moveVelocity.x = CrossPlatformInputManager.GetAxis("Horizontal") * moveSpeed;
            _moveVelocity.z = CrossPlatformInputManager.GetAxis("Vertical") * moveSpeed;

            // 移動方向に向く
            _transform.LookAt(_transform.position + new Vector3(_moveVelocity.x, 0, _moveVelocity.z));
        }
        else
        {
            _moveVelocity.x = 0;
            _moveVelocity.z = 0;
        }

        // Y軸方向は重力による加速が必要なため、別途計算
        if (IsGrounded)
        {
            if (Input.GetButtonDown("Jump"))
            {
                // ジャンプ処理
                Debug.Log("ジャンプ！");
                _moveVelocity.y = jumpPower; // ジャンプの際は上方向にジャンプの初速を加える
            }
        }
        else
        {
            // 重力による加速
            _moveVelocity.y += Physics.gravity.y * Time.deltaTime;
        }

        // オブジェクトを動かす
        _characterController.Move(_moveVelocity * Time.deltaTime);
        
        // 移動スピードをanimatorに反映
        animator.SetFloat("MoveSpeed", new Vector3(_moveVelocity.x, 0, _moveVelocity.z).magnitude);
    }
}
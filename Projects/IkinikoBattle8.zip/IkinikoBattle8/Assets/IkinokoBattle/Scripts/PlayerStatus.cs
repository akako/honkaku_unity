﻿using UnityEngine;

public class PlayerStatus : MobStatus
{
    // TODO あとでプレイヤー向けにカスタムする
}